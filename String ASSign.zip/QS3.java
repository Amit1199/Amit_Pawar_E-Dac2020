class QS3{

static int navin(char[]a,int n)
{
	if(n==0 || n==1)
	{
		return n;
	}

	char[] temp= new char[n];
	int j=0;

	for(int i=0;i<n-1;i++)
	{
		if(a[i]!=a[i+1])
		temp[j++]=a[i];
	} 

	   temp[j++] = a[n-1];     
        // Changing original array  
        for (int i=0; i<j; i++)
	{  
            a[i] = temp[i];  
        }  
        return j;  
    }  


public static void main(String []args)
{
	String s="abccddde";
	char[] c=new char[s.length()];
	for(int i=0;i<s.length();i++)
	{
		c[i]=s.charAt(i);
	}
	
	int len=navin(c,c.length);

	 for (int i=0; i<len; i++)  
           System.out.print(c[i]+" ");  
}
}