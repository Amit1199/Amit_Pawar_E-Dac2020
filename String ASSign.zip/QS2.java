public class QS2{  

	static void Demo(String s)
	{
		switch(s)
		{
		case "one":
		System.out.print(" two");
		break;

		case "two":
		System.out.print(" three");
		break;

		
		case "three":
		System.out.print(" four");
		break;

		
		case "four":
		System.out.print(" five");
		break;

		
		case "five":
		System.out.print(" six");
		break;
		
		
		case "six":
		System.out.print(" seven");
		break;

		
		case "seven":
		System.out.print(" eight");
		break;

		
		case "eight":
		System.out.print(" nine");
		break;

		
		case "nine":
		System.out.print(" ten");
		break;

		default:
		System.out.print(" "+s);
		}	
	} 

	public static void main(String args[]){  
	String s1="There are three bugs and nine features"; 
 
	String[] words=s1.split("\\s");
		for(String w:words)
		{  
		Demo(w);
  	
		}  

	}
}