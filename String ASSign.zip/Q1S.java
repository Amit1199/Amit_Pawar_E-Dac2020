import java.util.*;
class Q1S{
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	
	System.out.print("Enter String");
	String st=sc.nextLine();
	int vowels=0;
	int digits=0;
	int consonants=0;
	int chara=0;
	for(int j=0;j<st.length();j++)
	{
		if(st.charAt(j)=='a' || st.charAt(j)=='e' || st.charAt(j)=='i' || st.charAt(j)=='o' || st.charAt(j)=='u' )
		{
			vowels++;

		}else if(st.charAt(j)>='0' && st.charAt(j)<='9' )
		{
			digits++;
		}
		else if((st.charAt(j)>='a' && st.charAt(j)<='z') || (st.charAt(j)>='A' && st.charAt(j)<='Z'))
		{
			consonants++;
		}
		else
		chara++;
	}
	System.out.println("vowels= "+vowels);
	System.out.println("digits= "+digits);
	System.out.println("consos= "+consonants);
	System.out.println("Characters= "+chara);
			
	}
}