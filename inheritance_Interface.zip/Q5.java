interface Company{
	final String n="GOOGLE";
	void displayDetails();
}

class Employee{
	String type;
	Employee(String type)
	{
	this.type=type;
	}
}

class Salary Extends Employee implements Company
{
String name;
int empid;
float sal;
	Salary(String n,String type,int a,float b)
	{
	super(type);
	name=n;
	empid=a;
	sal=b;
	}
	public void displayDetails()
	{
		System.out.println("company"+n);
		System.out.println("name"+name);
		System.out.println("ID"+empid);
		System.out.println("Salary"+sal);
	}

		
}
class Q5{
public static void main(String args[]){
	Employee s=new Salary("Amit",1516530,12500.2f);
	s.displayDetails();

	}
} 