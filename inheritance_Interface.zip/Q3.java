interface School{
	final String n="CDAC MUMBAI";
	void displayDetail();
}
class Student implements School{
String name;
int batch;
int marks;
	Student(String a,int b,int m)
	{
		name=a;
		batch=b;
		marks=m;
	}
	public void displayDetail()
	{
		System.out.println(n);
		System.out.println("Name:"+name);
		System.out.println("Batch:"+batch);
		System.out.println("marks:"+marks);	
	}
}
class Teacher implements School{
String name;
String sub;
int exp;
	Teacher(String a,String b,int m)
	{
		name=a;
		sub=b;
		exp=m;
	}
	public void displayDetail()
	{
		System.out.println(n);
		System.out.println("Name:"+name);
		System.out.println("Subject:"+sub);
		System.out.println("Exp (in years):"+exp);	
	}
}
class Q3{
public static void main(String args[]){
	Student s=new Student("Amit Pawar",2020,500);
	Teacher t=new Teacher("Vipul Sir","Everything",3);
	System.out.println();
	s.displayDetail();
	System.out.println();
	t.displayDetail();
	}
}
