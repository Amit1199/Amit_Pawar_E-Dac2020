class Employee{
String name;
String com_name;
String type;
int empId;
String Role;
float sal;

	Employee(String com_name,String type)
	{
		this.com_name=com_name;
		this.type=type;
	}

	void displayDetails()
	{
		System.out.println("Company:"+com_name);
		System.out.println("Employee Type:"+type);
	}
}

class Manager extends Employee{
	Manager(String name,String com_name,String type,int empId,String Role,float sal)
	{
		super(com_name,type);
		this.name=name;
		this.empId=empId;
		this.Role=Role;
		this.sal=sal;
	}
	
	void displayDetails()
	{
		System.out.println("Name:"+name);
		
		super.displayDetails();
		System.out.println("Employee Id:"+empId);
		System.out.println("Employee Role:"+Role);
		System.out.println("Employee Salery:"+sal);
	}
}

class Worker extends Employee{
	Worker(String name,String com_name,String type,int empId,String Role,float sal)
	{
		super(com_name,type);
		this.name=name;
		this.empId=empId;
		this.Role=Role;
		this.sal=sal;
	}
	
	void displayDetails()
	{
		System.out.println("Name:"+name);
		
		super.displayDetails();
		System.out.println("Employee Id:"+empId);
		System.out.println("Employee Role:"+Role);
		System.out.println("Employee Salery:"+sal);
	}

}

class Q2{
public static void main(String args[]){

	Employee e=new Manager("Amit Pawar","GOOGLE","Manager",10089681,"Developer",25600.2f);

	Employee g=new Worker("Bill gates","GOOGLE","Worker",10089600,"Assistant",15600.2f);
	e.displayDetails();
	System.out.println();
	g.displayDetails();
	}
}