interface College{
	final String n="CDAC MUMBAI";
	void displayDetails();
}

interface Exam{
	String results();
}

class Students implements College,Exam{
String name;
int marks;
String res;
	Students(String n,int a)
	{
	name=n;
	marks=a;
	}
	public String results()
	{
		if(marks>40 && marks<100)
		{
			return "PASS";
		}
		else
			return "FAIL";
	}

	public void displayDetails()
	{
	System.out.println(n);
	System.out.println("Name:"+name);
	System.out.println("Marks:"+marks);
	}	
}
class Q4{
public static void main(String args[]){
	Students s=new Students("Amit",30);
	s.displayDetails();
	System.out.println(s.results());
	}
} 