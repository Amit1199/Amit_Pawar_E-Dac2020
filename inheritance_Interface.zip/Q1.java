class Bank{
String name;
int no;

String bank_name;
String acc;


	Bank(String n,String a)
	{
		bank_name=n;
		acc=a;
	}
	
	void DisplayAccountDetails()
	{
		System.out.println("Name:"+name);
		System.out.println("Acc.NO:"+no);
	}
}

class Customer extends Bank{
	Customer(String m,String n,int k, String a)
	{
	super(n,a);
	name=m;
	no=k;	
	}
	void DisplayAccountDetails()
	{
		super.DisplayAccountDetails();
		System.out.println("Bank:"+bank_name);
		System.out.println("Type:"+acc);
	}

}

class Q1{
public static void main(String args[])
{
	Bank y=new Customer("Amit","State Bank Of India",83082704,"Savings");
	y.DisplayAccountDetails();
}
}