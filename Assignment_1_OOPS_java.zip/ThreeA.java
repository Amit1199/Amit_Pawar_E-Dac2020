class ThreeA{
public static void main(String []args)
{
int x=50;
int y = (x*x) + 3*x - 7;
 System.out.println("y="+y);
}
}