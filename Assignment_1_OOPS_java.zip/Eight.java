import java.util.*;
class Eight{

public static void main(String []args)
{
	Scanner sc=new Scanner (System.in);
	System.out.print("principle amount: ₹ ");
	float p=sc.nextFloat();
	System.out.print("rate of interest(% per annum):");
	float r=sc.nextFloat();
	System.out.print("time(years):");
	int t =sc.nextInt() ;
	
	float SI=Math.round((p*r*t)/100*100.0)/100;
	

	System.out.println("Simple Interest = ₹ "+SI);
}
}