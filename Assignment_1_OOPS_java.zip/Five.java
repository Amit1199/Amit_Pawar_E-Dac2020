
class Five{

public static void main(String []args)
{
String x=args[0];
System.out.println("Welcome "+x);
}
}