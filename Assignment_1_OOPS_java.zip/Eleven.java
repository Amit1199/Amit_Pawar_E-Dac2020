import java.util.*;

class Eleven{

public static void main(String []args)
{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter 1st number (a)=");
	int a=sc.nextInt();
	System.out.print("Enter 1st number (b)=");
	int b=sc.nextInt();
	a=a+b;
	b=a-b;
	a=a-b;
	
	System.out.println("a = "+a);
	System.out.println("b = "+b);
}
}