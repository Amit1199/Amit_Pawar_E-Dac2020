import java.util.*;
class Thirteen{
	public static void main(String []args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter 1st number = ");
	int x=sc.nextInt();
	System.out.print("Enter 2nd number = ");
	int y=sc.nextInt();
	System.out.print("Enter 3rd number = ");
	int z=sc.nextInt();
	
	if(x>y && x>z)
	{
		System.out.print("Greatest number = "+x);
	}
	else
	{
	if(y>z)
		System.out.println("Greatest number = "+y);
	
	else
		System.out.println("Greatest number = "+z);
	}
}
}