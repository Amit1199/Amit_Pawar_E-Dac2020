import java.util.*;
class Seven{
	public static void main(String []args)
	{
	Scanner sc=new Scanner(System.in);
	float sum=0.0f;
	for(int i=1;i<=5;i++)
	{
		System.out.print("Subject "+i+" marks = ");
		int ai=sc.nextInt();
		sum=sum+ai;
	}
	float z= sum / 5 ;

	System.out.println("percentage marks = "+z+" %");
}
}