import java.util.Scanner;

class Ten{
public static void main(String []args)
{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Temperature in(.f):");
	float f=sc.nextFloat();
	float C= 5*(f-32)/9f;
	System.out.print("Temperature in(.C):"+C+" C");
}
}