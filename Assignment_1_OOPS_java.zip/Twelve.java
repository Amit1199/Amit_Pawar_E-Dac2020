import java.util.*;

class Twelve{
public static void main(String []args)
{
	Scanner sc=new Scanner(System.in);
	double DA;
	double HRA;
	System.out.print("Enter Your Basic Salary = RS ");
	double BS=sc.nextDouble();
	if(BS<10000)
	{
	HRA=0.10*BS;
	DA=0.90*BS;
	}
	else
	{
	HRA=2000;
	DA=0.98*BS;
	}
	
	double GS= (float)Math.round((BS + DA + HRA)*100.0)/100;	
	System.out.printf("%.2f",GS);
}
}