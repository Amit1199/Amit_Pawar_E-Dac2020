import java.util.*; 
class Six{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Radius of Circle(mm) = ");
		float r=sc.nextFloat();
		float pi=3.14f;
		float area=pi*r*r;
		area=(float)Math.round(area*100.0) / 100;
		float circum=2*pi*r;
		circum=(float)Math.round(circum*100.0) / 100;	
		System.out.println("Area of circle = "+area+" mm2");
		System.out.println("Circumference of the circle = "+circum+" mm");
	}
}