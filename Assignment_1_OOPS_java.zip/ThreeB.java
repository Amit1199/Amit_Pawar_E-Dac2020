class ThreeB{
public static void main(String []args)
{
int x=10;
System.out.println(++x);
System.out.println(x++);
System.out.println(x);
int y = x++ + ++x ;
//System.out.println("y = "+y);
}
}