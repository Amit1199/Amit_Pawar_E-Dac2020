import java.util.*;
class Nine{
public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter number of days:");
	int days=sc.nextInt();
	int year=days/365;
	int rday=days-(year*365);
	int months=rday/30;
	int rweek=rday-(months*30);
	int week=rweek/7;
	int day=week%7;
	System.out.print("number of years:"+year+" year ");
	System.out.print(months+" months ");
	System.out.print(week+"  Weeks ");
	System.out.println(day+"  Dayss ");
}
}

