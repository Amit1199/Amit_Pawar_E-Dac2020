import java.util.*;
class Fifteen{

public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Gender(m/f):");
	char c=sc.next().charAt(0);
	System.out.print("Enter Age:");
	int age=sc.nextInt();
	
	if(c=='m')
	{
		if(age>=21)
			System.out.print("you are eligible for marriage");
		else
			System.out.print("you are  not eligible for marriage");
	}
	

	if(c=='f')
	{
		if(age>=18)
			System.out.print("you are eligible for marriage");
		else
			System.out.print("you are  not eligible for marriage");
	}
	
	sc.close();
}
}