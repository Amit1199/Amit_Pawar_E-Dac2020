class Four{
public static void main(String []args)
{
short x=200;
byte b=(byte)x;
System.out.println("b(byte) = "+b);
}
}