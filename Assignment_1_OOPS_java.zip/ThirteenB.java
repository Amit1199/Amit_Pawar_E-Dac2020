import java.util.*;
class ThirteenB{
	public static void main(String []args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter 1st number = ");
	int x=sc.nextInt();
	System.out.print("Enter 2nd number = ");
	int y=sc.nextInt();
	System.out.print("Enter 3rd number = ");
	int z=sc.nextInt();
	int temp=x>y?x:y;
	int result=z>temp ? z:temp;
	System.out.print("Largest number = "+result);
}
}